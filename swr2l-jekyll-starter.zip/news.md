---
layout: default
title: News
---

# News Highlights

- ✅ Group started
- ✅ New lab!
- ✅ Xavi presents at webinar
- ✅ Xavi visits UBC
- ✅ Xavi presents in AD conference
- ✅ Xavi gives lecture in Denton
- ✅ Project WRF starts
- ✅ Demonstration unit and community engagement
- ✅ Papers published in 2024 and 2025
